package io.javabrains.springbootstarter.topic;


import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TopicController {

	/*@RequestMapping("/topics")
	public String getAllTopics()
	{
		return"all topics.....";
	}*/
	
	@RequestMapping("/topics")
	public List<Topic> getAllTopics()
	{
		
		return Arrays.asList(new Topic("springID", "Spring_Framework","Spring framework is very good"),
				new Topic("spring_boot_ID", "Spring_Boot","Spring Boot is stand alone application framework"));
	}
	
	
}
